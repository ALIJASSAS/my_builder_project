import './globals.css'
import { Inter, Cairo } from 'next/font/google'

const inter = Inter({ subsets: ['latin'] })
const cairo = Cairo({ subsets: ['arabic', 'latin'] })

export const metadata = {
  title: 'ملخص المحتوى - تلخيص ذكي وسريع',
  description: 'خدمة تلخيص المحتوى باستخدام الذكاء الاصطناعي - حول النصوص الطويلة إلى ملخصات واضحة ومفيدة',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="ar" dir="rtl">
      <body className={cairo.className}>{children}</body>
    </html>
  )
}
