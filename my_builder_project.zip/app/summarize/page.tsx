'use client'

import { useState } from 'react'
import Header from '../../components/Header'
import Footer from '../../components/Footer'

export default function SummarizePage() {
  const [text, setText] = useState('')
  const [summary, setSummary] = useState('')
  const [isLoading, setIsLoading] = useState(false)

  const handleSummarize = async () => {
    if (!text.trim()) return

    setIsLoading(true)
    // محاكاة عملية التلخيص
    await new Promise(resolve => setTimeout(resolve, 2000))

    // مثال على تلخيص بسيط (يمكن استبداله بـ API حقيقي لاحقاً)
    const sentences = text.split('.').filter(s => s.trim())
    const summaryText = sentences.slice(0, Math.max(1, Math.floor(sentences.length / 3))).join('. ') + '.'

    setSummary(summaryText)
    setIsLoading(false)
  }

  const clearAll = () => {
    setText('')
    setSummary('')
  }

  return (
    <main className="min-h-screen gradient-bg">
      <Header currentPage="summarize" />

      {/* Main Content */}
      <section className="container mx-auto px-6 py-8">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-4xl font-bold text-center text-gray-800 mb-8">
            تلخيص المحتوى الذكي
          </h1>
          
          <div className="grid lg:grid-cols-2 gap-8">
            {/* Input Section */}
            <div className="bg-white rounded-2xl shadow-lg p-6">
              <h2 className="text-2xl font-semibold text-gray-800 mb-4 flex items-center">
                <svg className="w-6 h-6 ml-2 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                </svg>
                النص المراد تلخيصه
              </h2>
              
              <textarea
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="أدخل النص الذي تريد تلخيصه هنا..."
                className="w-full h-64 p-4 border border-gray-300 rounded-xl resize-none focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-gray-700"
                dir="rtl"
              />
              
              <div className="flex justify-between items-center mt-4">
                <span className="text-sm text-gray-500">
                  عدد الأحرف: {text.length}
                </span>
                <div className="flex gap-3">
                  <button
                    onClick={clearAll}
                    className="px-4 py-2 text-gray-600 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    مسح الكل
                  </button>
                  <button
                    onClick={handleSummarize}
                    disabled={!text.trim() || isLoading}
                    className="px-6 py-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg font-semibold hover:from-blue-700 hover:to-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                  >
                    {isLoading ? 'جاري التلخيص...' : 'لخص النص'}
                  </button>
                </div>
              </div>
            </div>

            {/* Output Section */}
            <div className="bg-white rounded-2xl shadow-lg p-6">
              <h2 className="text-2xl font-semibold text-gray-800 mb-4 flex items-center">
                <svg className="w-6 h-6 ml-2 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
                الملخص
              </h2>
              
              <div className="min-h-64 p-4 border border-gray-300 rounded-xl bg-gray-50">
                {isLoading ? (
                  <div className="flex items-center justify-center h-64">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
                  </div>
                ) : summary ? (
                  <div>
                    <p className="text-gray-700 leading-relaxed" dir="rtl">
                      {summary}
                    </p>
                    <div className="mt-4 pt-4 border-t border-gray-200">
                      <div className="flex justify-between text-sm text-gray-500">
                        <span>طول النص الأصلي: {text.length} حرف</span>
                        <span>طول الملخص: {summary.length} حرف</span>
                      </div>
                      <div className="mt-2">
                        <span className="text-sm text-green-600">
                          نسبة الضغط: {Math.round((1 - summary.length / text.length) * 100)}%
                        </span>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center justify-center h-64 text-gray-400">
                    <div className="text-center">
                      <svg className="w-16 h-16 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                      </svg>
                      <p>سيظهر الملخص هنا بعد الضغط على "لخص النص"</p>
                    </div>
                  </div>
                )}
              </div>
              
              {summary && (
                <div className="flex gap-3 mt-4">
                  <button
                    onClick={() => navigator.clipboard.writeText(summary)}
                    className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors flex items-center"
                  >
                    <svg className="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                    </svg>
                    نسخ
                  </button>
                  <button
                    onClick={() => setSummary('')}
                    className="px-4 py-2 border border-gray-300 text-gray-600 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    مسح الملخص
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Tips Section */}
          <div className="mt-12 bg-white rounded-2xl shadow-lg p-6">
            <h3 className="text-xl font-semibold text-gray-800 mb-4">نصائح للحصول على أفضل النتائج</h3>
            <div className="grid md:grid-cols-3 gap-4">
              <div className="flex items-start space-x-3 space-x-reverse">
                <div className="flex-shrink-0 w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                  <span className="text-blue-600 font-semibold text-sm">1</span>
                </div>
                <div>
                  <h4 className="font-medium text-gray-800">نص واضح</h4>
                  <p className="text-sm text-gray-600">تأكد من أن النص واضح ومقروء</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3 space-x-reverse">
                <div className="flex-shrink-0 w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                  <span className="text-purple-600 font-semibold text-sm">2</span>
                </div>
                <div>
                  <h4 className="font-medium text-gray-800">طول مناسب</h4>
                  <p className="text-sm text-gray-600">النصوص الأطول تعطي ملخصات أفضل</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3 space-x-reverse">
                <div className="flex-shrink-0 w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                  <span className="text-green-600 font-semibold text-sm">3</span>
                </div>
                <div>
                  <h4 className="font-medium text-gray-800">مراجعة النتائج</h4>
                  <p className="text-sm text-gray-600">راجع الملخص وتأكد من دقته</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
