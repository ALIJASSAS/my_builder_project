export default function Footer() {
  return (
    <footer className="container mx-auto px-6 py-8 border-t border-gray-200">
      <div className="text-center text-gray-600">
        <p>&copy; 2024 ملخص المحتوى. جميع الحقوق محفوظة.</p>
        <div className="mt-4 flex justify-center space-x-6 space-x-reverse">
          <a href="#" className="hover:text-blue-600 transition-colors">سياسة الخصوصية</a>
          <a href="#" className="hover:text-blue-600 transition-colors">شروط الاستخدام</a>
          <a href="#" className="hover:text-blue-600 transition-colors">اتصل بنا</a>
        </div>
      </div>
    </footer>
  )
}
