import Link from 'next/link'

interface HeaderProps {
  currentPage?: 'home' | 'summarize'
}

export default function Header({ currentPage = 'home' }: HeaderProps) {
  return (
    <header className="container mx-auto px-6 py-8">
      <nav className="flex justify-between items-center">
        <Link href="/" className="text-2xl font-bold text-gray-800 hover:text-blue-600 transition-colors">
          ملخص المحتوى
        </Link>
        <div className="flex space-x-6 space-x-reverse">
          <Link 
            href="/" 
            className={`transition-colors ${
              currentPage === 'home' 
                ? 'text-blue-600 font-semibold' 
                : 'text-gray-600 hover:text-blue-600'
            }`}
          >
            الرئيسية
          </Link>
          <Link 
            href="/summarize" 
            className={`transition-colors ${
              currentPage === 'summarize' 
                ? 'text-blue-600 font-semibold' 
                : 'text-gray-600 hover:text-blue-600'
            }`}
          >
            التلخيص
          </Link>
        </div>
      </nav>
    </header>
  )
}
